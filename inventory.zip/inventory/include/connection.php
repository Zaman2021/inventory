<?php
  $conn = mysqli_connect("localhost","root","","Inventory");

  if (!$conm) {
    die("Connection was Errored",mysqli_connect_error());
  }


 ?>
