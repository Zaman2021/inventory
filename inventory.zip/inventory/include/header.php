<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
	  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="boot/css/bootstrap.min.css">
<link rel="stylesheet" href="boot/css/myCss.css">
<!-- jQuery library -->
<script src="boot/js/jquery.min.js"></script>

<!-- Popper JS -->
<script src="boot/js/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="boot/js/bootstrap.min.js"></script>
    <title>ذخیره انبار</title>
  </head>
  <body>
  <div class="container-fluid">
    <div class="row" id = "top">
        <div class="col-md-6" id="logo">
          <img class="img-responsive" src="img/logo.jpg">
        </div>
        <div class="col-md-1">

        </div>
        <div class="col-md-5">
          <h1 class="titleheader" id="companyname">شرکت خدماتی نرم افزاری هما</h1>
        </div>
      </div>
